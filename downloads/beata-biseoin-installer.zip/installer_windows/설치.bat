@echo off
chcp 65001 >nul
title 베아타 비서인 설치
echo.
echo  베아타 비서인을 설치합니다...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
