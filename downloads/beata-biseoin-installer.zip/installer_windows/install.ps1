# 베아타 비서인 설치 스크립트 (Windows)
# 실행: 설치.bat 더블클릭 (또는 PowerShell에서 직접 실행)
# 하는 일: 1) Node.js 확인  2) Claude Code 설치  3) API 키 등록  4) 비서인 작업폴더 구성

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Say($msg, $color="White") { Write-Host $msg -ForegroundColor $color }

Say "==================================================" "Cyan"
Say "      베아타 비서인 설치 (Windows)" "Cyan"
Say "==================================================" "Cyan"
Say ""

# --- 0) 작업 폴더 결정 ---
$HomeDir = [Environment]::GetFolderPath("UserProfile")
$WorkDir = Join-Path $HomeDir "베아타-비서인"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload = Join-Path $ScriptDir "payload"

# --- 1) Node.js 확인 (Claude Code npm 설치에 필요) ---
Say "[1/4] Node.js 확인 중..." "Yellow"
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
    Say "  Node.js가 없습니다. winget으로 설치를 시도합니다..." "Yellow"
    try {
        winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
        Say "  Node.js 설치 완료. 이 창을 닫고 설치.bat를 다시 실행해 주세요." "Green"
    } catch {
        Say "  자동 설치 실패. https://nodejs.org 에서 LTS 버전을 설치한 뒤 다시 실행해 주세요." "Red"
    }
    Read-Host "엔터를 누르면 종료합니다"
    exit
}
Say "  OK: $(node --version)" "Green"

# --- 2) Claude Code 설치 ---
Say "[2/4] Claude Code 확인/설치 중..." "Yellow"
$claude = Get-Command claude -ErrorAction SilentlyContinue
if (-not $claude) {
    Say "  Claude Code 설치 중 (npm)..." "Yellow"
    npm install -g "@anthropic-ai/claude-code"
    Say "  설치 완료." "Green"
} else {
    Say "  이미 설치됨. 최신화합니다..." "Green"
    npm install -g "@anthropic-ai/claude-code" 2>$null
}

# --- 3) API 키 등록 (BYOK — 키는 이 PC에만 저장) ---
Say "[3/4] Anthropic API 키 등록" "Yellow"
$existing = [Environment]::GetEnvironmentVariable("ANTHROPIC_API_KEY", "User")
if ($existing) {
    Say "  이미 등록된 키가 있습니다. 유지합니다. (변경하려면 직접 환경변수 수정)" "Green"
} else {
    Say "  Anthropic 콘솔(console.anthropic.com)에서 발급한 API 키를 입력하세요." "White"
    Say "  (입력값은 이 PC의 사용자 환경변수에만 저장되며 외부로 전송되지 않습니다.)" "DarkGray"
    $key = Read-Host "  ANTHROPIC_API_KEY"
    if ($key.Trim().Length -gt 0) {
        [Environment]::SetEnvironmentVariable("ANTHROPIC_API_KEY", $key.Trim(), "User")
        Say "  키 저장 완료." "Green"
    } else {
        Say "  키 미입력 — 나중에 'claude' 첫 실행 시 로그인으로 진행해도 됩니다." "Yellow"
    }
}

# --- 4) 비서인 작업폴더 구성 (CLAUDE.md + 슬래시명령 + 메모리) ---
Say "[4/4] 비서인 작업폴더 구성: $WorkDir" "Yellow"
New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
Copy-Item -Recurse -Force (Join-Path $Payload "*") $WorkDir
# 자료 폴더 안내용
New-Item -ItemType Directory -Force -Path (Join-Path $WorkDir "자료") | Out-Null
Say "  완료. CLAUDE.md / 슬래시명령 / 메모리 설치됨." "Green"

Say ""
Say "==================================================" "Cyan"
Say " 설치 완료!" "Green"
Say "==================================================" "Cyan"
Say " 사용법:" "White"
Say "  1) 새 PowerShell 또는 터미널을 엽니다 (환경변수 적용)" "White"
Say "  2) 다음을 입력:" "White"
Say "       cd `"$WorkDir`"" "Cyan"
Say "       claude" "Cyan"
Say "  3) 비서에게 말 걸기 예시:" "White"
Say "       /시장조사 국내 기능성 음료 시장" "DarkGray"
Say "       /제안서 OO유통 입점 제안" "DarkGray"
Say ""
Say " 자료(문서)는  $WorkDir\자료  폴더에 넣으면 비서가 읽습니다." "White"
Say ""
Read-Host "엔터를 누르면 종료합니다"
